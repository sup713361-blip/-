plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val bn = (project.findProperty("buildNumber") as String?)?.toIntOrNull() ?: 1

android {
    namespace = "com.example.pixellauncher"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.pixellauncher"
        minSdk = 21
        targetSdk = 35
        versionCode = bn
        versionName = "1.$bn"
    }
    signingConfigs {
        create("fixed") {
            storeFile = file("launcher.keystore")
            val pass = System.getenv("KS_PASS")
                ?: throw GradleException("Нет секрета KS_PASS: GitHub -> Settings -> Secrets and variables -> Actions -> New repository secret")
            storePassword = pass
            keyAlias = "launcher"
            keyPassword = pass
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("fixed") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
}
