package com.example.pixellauncher

import android.app.KeyguardManager
import android.animation.ValueAnimator
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder

// Живые обои: на экране блокировки фигура с кусочком фото, при разблокировке она расширяется до краёв
class ShapeWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = ShapeEngine()

    inner class ShapeEngine : Engine() {
        private val art = ShapeWall(this@ShapeWallpaperService)
        private val h = Handler(Looper.getMainLooper())
        private val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        private var visible = false
        private var wasLocked = false
        private var p = 1f
        private var anim: ValueAnimator? = null

        private fun locked() = if (Build.VERSION.SDK_INT >= 22) km.isKeyguardLocked else km.inKeyguardRestrictedInputMode()

        private val poll = object : Runnable {
            override fun run() {
                if (!visible) return
                val l = locked()
                if (l != wasLocked) {
                    wasLocked = l
                    if (l) { anim?.cancel(); p = 0f; draw() } else play()
                }
                h.postDelayed(this, 50)
            }
        }

        private fun load() {
            val pr = getSharedPreferences("launcher", MODE_PRIVATE)
            art.shape = pr.getInt("sh_shape", 1)
            art.bg = pr.getInt("sh_color", 0xFF1C2333.toInt())
            art.size = pr.getInt("sh_size", 55)
            art.zoom = pr.getInt("sh_zoom", 50)
            if (art.photo == null) {
                art.photo = BitmapFactory.decodeFile(java.io.File(filesDir, "shape.jpg").path)
                    ?: BitmapFactory.decodeResource(resources, R.drawable.wall_palm)
            }
        }

        private fun play() {
            anim?.cancel()
            anim = ValueAnimator.ofFloat(p, 1f).apply {
                duration = 650
                addUpdateListener { p = it.animatedValue as Float; draw() }
                start()
            }
        }

        private fun draw() {
            runCatching {
                val sh = surfaceHolder
                val cv = (if (Build.VERSION.SDK_INT >= 26) sh.lockHardwareCanvas() else sh.lockCanvas()) ?: return
                try {
                    art.render(cv, sh.surfaceFrame.width().toFloat(), sh.surfaceFrame.height().toFloat(), p)
                } finally {
                    sh.unlockCanvasAndPost(cv)
                }
            }
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            h.removeCallbacks(poll)
            if (v) {
                art.photo = null
                load()
                wasLocked = locked()
                p = if (wasLocked) 0f else 1f
                draw()
                h.post(poll)
            } else {
                anim?.cancel()
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            draw()
        }

        override fun onSurfaceRedrawNeeded(holder: SurfaceHolder) { draw() }

        override fun onDestroy() {
            h.removeCallbacks(poll)
            anim?.cancel()
            super.onDestroy()
        }
    }
}
