package com.example.pixellauncher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.app.ActivityOptions
import android.app.WallpaperManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.InputType
import android.text.TextUtils
import android.view.DragEvent
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.RoundedCorner
import android.view.View
import android.view.ViewAnimationUtils
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.animation.PathInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Space
import android.widget.TextClock
import android.widget.Toast
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.doAfterTextChanged

class App(val label: String, val pkg: String, val icon: Drawable, val intent: Intent)

// Обои «Фигуры» как в Google Pixel. t: 0 - экран блокировки (фигура с кусочком фото), 1 - фото на весь экран
class ShapeWall(c: Context) : View(c) {
    var shape = 1
    var bg = 0xFF1C2333.toInt()
    var size = 55
    var zoom = 50
    var photo: Bitmap? = null
    var p = 0f
    private val pt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var shader: BitmapShader? = null
    private var shaderFor: Bitmap? = null

    override fun onDraw(cv: Canvas) { render(cv, width.toFloat(), height.toFloat(), p) }

    fun render(cv: Canvas, w: Float, h: Float, t: Float) {
        val e = t * t * (3 - 2 * t)
        cv.drawColor(bg)
        val r0 = minOf(w, h) * (0.12f + 0.30f * size / 100f)
        val r = r0 + (Math.hypot(w.toDouble(), h.toDouble()).toFloat() * 0.8f - r0) * e
        val cx = w / 2
        val cy = h * 0.48f + h * 0.02f * e
        val ph = photo
        val s1 = if (ph != null) maxOf(w / ph.width, h / ph.height) else 1f
        val s0 = if (ph != null) maxOf(2 * r0 / ph.width, 2 * r0 / ph.height) * (1f + 2f * zoom / 100f) else 1f
        val sc = s0 + (s1 - s0) * e
        val m = Matrix()
        if (ph != null) { m.setScale(sc, sc); m.postTranslate(cx - ph.width * sc / 2, cy - ph.height * sc / 2) }
        if (t >= 0.999f && ph != null) { cv.drawBitmap(ph, m, null); return }
        path.reset()
        val n = 240
        for (i in 0..n) {
            val a = i * 2.0 * Math.PI / n
            val k = when (shape) {
                0 -> 1.0
                1 -> 0.9 / Math.pow(Math.pow(Math.abs(Math.cos(a)), 4.0) + Math.pow(Math.abs(Math.sin(a)), 4.0), 0.25)
                2 -> 0.94 + 0.06 * Math.cos(9 * a)
                else -> 0.82 + 0.18 * Math.cos(8 * a)
            }
            val x = cx + (r * k * Math.cos(a)).toFloat()
            val y = cy + (r * k * Math.sin(a)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        if (ph != null) {
            if (shaderFor !== ph) { shader = BitmapShader(ph, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP); shaderFor = ph }
            shader!!.setLocalMatrix(m)
            pt.shader = shader
        } else {
            pt.shader = null
            pt.color = Color.BLACK
        }
        cv.drawPath(path, pt)
    }
}

class MainActivity : Activity() {
    private var all = listOf<App>()
    private var isOpen = false
    private lateinit var root: FrameLayout
    private lateinit var dock: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var grid: GridView
    private lateinit var search: EditText
    private lateinit var desk: FrameLayout
    private lateinit var panel: LinearLayout
    private lateinit var scrim: View
    private lateinit var settings: ScrollView
    private lateinit var box: LinearLayout
    private lateinit var bar: LinearLayout
    private val placed = LinkedHashMap<String, Int>()
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }
    private val cols get() = prefs.getInt("cols", 4)
    private val isz get() = dp(prefs.getInt("isize", 56))
    private val iconRun = Runnable { applyIcons() }
    private val styles = listOf("Окно из иконки", "Круг из иконки", "Масштаб", "Снизу вверх", "Затухание", "Пружина", "Без анимации")
    private lateinit var veil: View
    private lateinit var dots: TextView
    private lateinit var wallView: ImageView
    private lateinit var homeView: View
    private lateinit var shapeView: ShapeWall
    private var shapePrev: ShapeWall? = null
    private var shapePhoto: Bitmap? = null
    private val ol = RectF()
    private var orad = 0f
    private var lcx = 0
    private var lcy = 0
    private var awaiting = false
    private var va: ValueAnimator? = null
    private var vst = 0
    private var shape = 0
    private var closing = false
    private var crv = 0f
    private var left = false
    private var page = 0
    private val maxPages = 5

    // Цвета Material You (динамические, из обоев) + светлая/тёмная тема
    private val dark get() = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES
    private fun pick(night: Int, day: Int, nightFb: Long, dayFb: Long) =
        if (Build.VERSION.SDK_INT >= 31) ContextCompat.getColor(this, if (dark) night else day)
        else (if (dark) nightFb else dayFb).toInt()
    private val fg get() = pick(android.R.color.system_neutral1_50, android.R.color.system_neutral1_900, 0xFFEDEDED, 0xFF1B1B1F)
    private val sheet get() = pick(android.R.color.system_neutral1_900, android.R.color.system_neutral1_10, 0xFF1B1B1F, 0xFFFAFAFA)
    private val pillBg get() = pick(android.R.color.system_neutral2_800, android.R.color.system_accent2_100, 0xFF2E2F36, 0xFFE3E7F2)
    private val accent get() = pick(android.R.color.system_accent1_700, android.R.color.system_accent1_200, 0xFF3F51B5, 0xFFC5CAE9)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun round(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    private val ad = object : BaseAdapter() {
        var items = listOf<App>()
        override fun getCount() = items.size
        override fun getItem(p: Int) = items[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, v: View?, g: ViewGroup?): View {
            val a = items[p]
            val c = v as? LinearLayout ?: return cell(a, true)
            val iv = c.getChildAt(0) as ImageView
            iv.setImageDrawable(a.icon)
            if (iv.layoutParams.width != isz) iv.layoutParams = LinearLayout.LayoutParams(isz, isz)
            (c.getChildAt(1) as TextView).text = a.label
            return c
        }
    }

    private val gd by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null) return false
                val dy = e2.y - e1.y
                val dx = e2.x - e1.x
                if (!isOpen && !overlay() && Math.abs(dx) > dp(80) && Math.abs(dx) > Math.abs(dy) * 1.5f && Math.abs(vx) > 700) {
                    goPage(page + if (dx < 0) 1 else -1); return true
                }
                if (!isOpen && !overlay() && dy < -dp(60) && vy < -600) { show(true); return true }
                if (isOpen && dy > dp(80) && vy > 800 && !grid.canScrollVertically(-1)) { show(false); return true }
                return false
            }
        })
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        root = FrameLayout(this)
        loadDesk()
        ContextCompat.registerReceiver(this, object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) { reload() }
        }, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED); addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }, ContextCompat.RECEIVER_EXPORTED)

        // ---- Главный экран: дата, док, поиск ----
        val home = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setOnLongClickListener { panelShow(true); true }
        }
        home.addView(TextClock(this).apply {
            format12Hour = "EEE, d MMM"; format24Hour = "EEE, d MMM"
            textSize = 30f; setTextColor(Color.WHITE); setShadowLayer(8f, 0f, 2f, 0x66000000)
            typeface = Typeface.create("google-sans", Typeface.NORMAL)
        })
        desk = FrameLayout(this).apply {
            addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
                if (r - l != orr - ol || b - t != ob - ot) post { layoutDesk() }
            }
            setOnDragListener { _, e ->
                if (e.action == DragEvent.ACTION_DROP) dropOnDesk(e)
                true
            }
        }
        home.addView(desk, LinearLayout.LayoutParams(-1, 0, 1f))
        dots = TextView(this).apply { gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 12f; setShadowLayer(4f, 0f, 1f, 0x99000000.toInt()) }
        home.addView(dots, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        dock = LinearLayout(this).apply { gravity = Gravity.CENTER }
        home.addView(dock, LinearLayout.LayoutParams(-1, -2))
        val pill = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = round(pillBg, 28)
            setPadding(dp(20), 0, dp(20), 0)
            addView(ImageView(context).apply {
                setImageResource(android.R.drawable.ic_menu_search); setColorFilter(fg)
            }, LinearLayout.LayoutParams(dp(24), dp(24)))
            addView(TextView(context).apply {
                text = "Поиск"; textSize = 16f; setTextColor(fg); setPadding(dp(16), 0, 0, 0)
            })
            setOnClickListener { show(true, true) }
        }
        home.addView(pill, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(12) })

        // ---- Шторка приложений ----
        search = EditText(this).apply {
            hint = "Поиск приложений"; textSize = 16f
            setTextColor(fg); setHintTextColor(fg and 0x99FFFFFF.toInt())
            background = round(pillBg, 28)
            setPadding(dp(20), 0, dp(20), 0)
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_GO
            doAfterTextChanged { t ->
                val q = t?.toString() ?: ""
                ad.items = all.filter { it.label.contains(q, true) }
                ad.notifyDataSetChanged()
            }
            setOnEditorActionListener { _, _, _ -> ad.items.firstOrNull()?.let { launch(it, this) }; true }
        }
        grid = GridView(this).apply {
            numColumns = cols; verticalSpacing = dp(8); clipToPadding = false
            setPadding(dp(8), dp(8), dp(8), 0)
            selector = ColorDrawable(Color.TRANSPARENT)
            adapter = ad
            setOnItemClickListener { _, v, p, _ -> launch(ad.items[p], v) }
            setOnItemLongClickListener { _, v, p, _ -> drag(ad.items[p], v); true }
        }
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.INVISIBLE
            background = GradientDrawable().apply {
                setColor(sheet)
                setCornerRadii(FloatArray(8) { if (it < 4) dp(28).toFloat() else 0f })
            }
            addView(search, LinearLayout.LayoutParams(-1, dp(56)).apply { setMargins(dp(16), dp(8), dp(16), dp(8)) })
            addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        }

        wallView = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setImageResource(R.drawable.wall_palm) }
        root.addView(wallView, -1, -1)
        shapeView = ShapeWall(this)
        root.addView(shapeView, -1, -1)
        homeView = home
        applyWall()
        root.addView(home, -1, -1)
        root.addView(drawer, -1, -1)

        // ---- Нижняя панель (долгое нажатие), цели перетаскивания, настройки ----
        scrim = View(this).apply { setBackgroundColor(0x66000000); visibility = View.GONE; setOnClickListener { panelShow(false) } }
        panel = LinearLayout(this).apply {
            visibility = View.GONE
            background = GradientDrawable().apply {
                setColor(sheet)
                setCornerRadii(FloatArray(8) { if (it < 4) dp(28).toFloat() else 0f })
            }
            val lp = { LinearLayout.LayoutParams(0, dp(56), 1f).apply { setMargins(dp(8), 0, dp(8), 0) } }
            addView(chip("Обои", false) {
                panelShow(false)
                wallShow()
            }, lp())
            addView(chip("Настройки лаунчера", false) { panelShow(false); settingsShow(true) }, lp())
        }
        bar = LinearLayout(this).apply {
            alpha = 0f
            addView(target("Убрать") { placed.remove(it); saveDesk(); desk.post { layoutDesk() } }, tl())
            addView(target("О приложении") { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$it"))) }, tl())
            addView(target("Удалить") { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$it"))) }, tl())
        }
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        settings = ScrollView(this).apply { visibility = View.GONE; setBackgroundColor(sheet); addView(box) }
        root.addView(scrim, -1, -1)
        root.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        root.addView(bar, FrameLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(8), dp(12), 0) })
        root.addView(settings, -1, -1)
        veil = View(this).apply {
            visibility = View.INVISIBLE
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) {
                    if (shape == 1) o.setOval(ol.left.toInt(), ol.top.toInt(), ol.right.toInt(), ol.bottom.toInt())
                    else o.setRoundRect(ol.left.toInt(), ol.top.toInt(), ol.right.toInt(), ol.bottom.toInt(), orad)
                }
            }
        }
        root.addView(veil, -1, -1)
        root.setOnDragListener { _, e ->
            if (e.action == DragEvent.ACTION_DRAG_STARTED) bar.animate().alpha(1f).setDuration(120).start()
            if (e.action == DragEvent.ACTION_DRAG_ENDED) bar.animate().alpha(0f).setDuration(120).start()
            true
        }
        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, w ->
            val b = w.getInsets(WindowInsetsCompat.Type.systemBars())
            val bottom = maxOf(b.bottom, w.getInsets(WindowInsetsCompat.Type.ime()).bottom)
            home.setPadding(dp(16), b.top + dp(24), dp(16), bottom + dp(16))
            drawer.setPadding(0, b.top, 0, bottom)
            settings.setPadding(dp(24), b.top + dp(16), dp(24), bottom + dp(16))
            panel.setPadding(dp(16), dp(24), dp(16), bottom + dp(24))
            (bar.layoutParams as FrameLayout.LayoutParams).topMargin = b.top + dp(8)
            bar.requestLayout()
            w
        }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        when {
            settings.visibility == View.VISIBLE -> settingsShow(false)
            scrim.visibility == View.VISIBLE -> panelShow(false)
            isOpen -> show(false)
        }
    }

    override fun onStart() {
        super.onStart()
        if (all.isEmpty()) reload()
        if (awaiting && left) {
            awaiting = false; left = false
            veil.postDelayed({ closeVeil() }, 50)
        } else if (!awaiting && veil.visibility == View.VISIBLE && va?.isRunning != true) {
            hideVeil()
        }
    }

    override fun onStop() {
        super.onStop()
        left = true
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (isOpen) show(false)
        settingsShow(false)
        if (scrim.visibility == View.VISIBLE) panelShow(false)
        if (awaiting && !left) { awaiting = false; closeVeil() }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gd.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    private fun cell(a: App, labels: Boolean, wall: Boolean = false) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(4), dp(8), dp(4), dp(8))
        addView(ImageView(context).apply { setImageDrawable(a.icon) }, LinearLayout.LayoutParams(isz, isz))
        if (labels) addView(TextView(context).apply {
            text = a.label; textSize = 12f; maxLines = 1
            ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
            setTextColor(if (wall) Color.WHITE else fg); setPadding(0, dp(4), 0, 0)
            if (wall) setShadowLayer(6f, 0f, 2f, 0x99000000.toInt())
        })
    }

    @Suppress("DEPRECATION")
    private fun reload() {
        Thread {
        val pm = packageManager
        val list = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),
            0
        ).filter { it.activityInfo.packageName != packageName }.map { r ->
            val p = r.activityInfo.packageName
            App(
                r.loadLabel(pm).toString(), p, shapeIcon(r.loadIcon(pm)),
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    .setClassName(p, r.activityInfo.name)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            )
        }.sortedBy { it.label.lowercase() }
        runOnUiThread { all = list; ad.items = list; ad.notifyDataSetChanged(); buildDock(); layoutDesk() }
        }.start()
    }

    @Suppress("DEPRECATION")
    private fun buildDock() {
        val pm = packageManager
        dock.removeAllViews()
        listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://")).addCategory(Intent.CATEGORY_BROWSABLE),
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        ).mapNotNull {
            pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)
                ?.activityInfo?.packageName
        }.distinct().mapNotNull { p -> all.firstOrNull { it.pkg == p } }.forEach { a ->
            dock.addView(
                cell(a, false).apply { setOnClickListener { launch(a, it) } },
                LinearLayout.LayoutParams(0, -2, 1f)
            )
        }
    }

    private fun rows() = maxOf(1, desk.height / (isz + dp(40)))

    private fun pages() = minOf(maxPages, maxOf(page, (placed.values.maxOrNull() ?: 0) / 100) + 2)

    private fun updateDots() { dots.text = (0 until pages()).joinToString("  ") { if (it == page) "●" else "○" } }

    private fun goPage(n: Int) {
        if (n < 0 || n >= pages() || n == page) return
        val dir = if (n > page) 1 else -1
        val sh = desk.width * 0.3f
        desk.animate().translationX(-dir * sh).alpha(0f).setDuration(120).withEndAction {
            page = n
            layoutDesk()
            desk.translationX = dir * sh
            desk.animate().translationX(0f).alpha(1f).setDuration(160).start()
        }.start()
    }

    private fun overlay() = settings.visibility == View.VISIBLE || scrim.visibility == View.VISIBLE

    private fun saveDesk() = prefs.edit().putString("desk", placed.entries.joinToString(",") { it.key + "=" + it.value }).apply()

    private fun loadDesk() {
        placed.clear()
        (prefs.getString("desk", "") ?: "").split(",").forEach { s ->
            val p = s.split("=")
            if (p.size == 2) p[1].toIntOrNull()?.let { placed[p[0]] = it }
        }
    }

    // Значки на рабочем столе: сетка cols x rows, позиция = ряд*10 + колонка
    private fun layoutDesk() {
        updateDots()
        if (desk.width == 0 || all.isEmpty()) return
        desk.removeAllViews()
        val cw = desk.width / cols
        val ch = desk.height / rows()
        placed.entries.toList().filter { it.value / 100 == page }.forEach { (pkg, pos) ->
            val a = all.firstOrNull { it.pkg == pkg } ?: return@forEach
            val c = cell(a, true, true).apply {
                setOnClickListener { launch(a, it) }
                setOnLongClickListener { drag(a, it); true }
            }
            desk.addView(c, FrameLayout.LayoutParams(cw, ch).apply {
                leftMargin = (pos % 10).coerceAtMost(cols - 1) * cw
                topMargin = ((pos % 100) / 10).coerceAtMost(rows() - 1) * ch
            })
        }
    }

    private fun dropOnDesk(e: DragEvent) {
        val pkg = e.clipData?.getItemAt(0)?.text?.toString() ?: return
        val rw = rows()
        val c = (e.x / (desk.width / cols)).toInt().coerceIn(0, cols - 1)
        val r = (e.y / (desk.height / rw)).toInt().coerceIn(0, rw - 1)
        placed.remove(pkg)
        val taken = placed.values.filter { it / 100 == page }.map { it % 100 }.toSet()
        val spot = (0 until rw * cols).map { (it / cols) * 10 + it % cols }.filter { it !in taken }
            .minByOrNull { val dr = it / 10 - r; val dc = it % 10 - c; dr * dr + dc * dc } ?: return
        placed[pkg] = page * 100 + spot
        saveDesk()
        desk.post { layoutDesk() }
    }

    @Suppress("DEPRECATION")
    private fun drag(a: App, v: View) {
        v.startDrag(ClipData.newPlainText("pkg", a.pkg), View.DragShadowBuilder(v), null, 0)
        if (isOpen) show(false)
    }

    private fun tl() = LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(4), 0, dp(4), 0) }

    private fun target(t: String, act: (String) -> Unit) = TextView(this).apply {
        text = t; textSize = 13f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        background = round(0xCC333333.toInt(), 24)
        setOnDragListener { v, e ->
            when (e.action) {
                DragEvent.ACTION_DRAG_ENTERED -> v.alpha = 0.6f
                DragEvent.ACTION_DRAG_EXITED, DragEvent.ACTION_DRAG_ENDED -> v.alpha = 1f
                DragEvent.ACTION_DROP -> e.clipData?.getItemAt(0)?.text?.toString()?.let(act)
            }
            true
        }
    }

    private fun chip(t: String, sel: Boolean, click: () -> Unit) = TextView(this).apply {
        text = t; textSize = 15f; gravity = Gravity.CENTER; setTextColor(fg)
        setPadding(dp(16), dp(12), dp(16), dp(12))
        background = round(if (sel) pick(android.R.color.system_accent1_700, android.R.color.system_accent1_200, 0xFF3F51B5, 0xFFC5CAE9) else pillBg, 28)
        setOnClickListener { click() }
    }

    private fun panelShow(v: Boolean) {
        if (v) {
            scrim.visibility = View.VISIBLE
            panel.visibility = View.VISIBLE
            panel.translationY = dp(200).toFloat()
            panel.animate().translationY(0f).setDuration(200).start()
        } else {
            scrim.visibility = View.GONE
            panel.animate().translationY(dp(200).toFloat()).setDuration(160)
                .withEndAction { if (scrim.visibility == View.GONE) panel.visibility = View.GONE }.start()
        }
    }

    private fun settingsShow(v: Boolean) {
        if (v) buildSettings()
        settings.visibility = if (v) View.VISIBLE else View.GONE
    }

    private fun applyWall() {
        val w = prefs.getString("wall", "palm")
        wallView.visibility = if (w == "palm") View.VISIBLE else View.GONE
        shapeView.visibility = if (w == "shape") View.VISIBLE else View.GONE
        var c = Color.WHITE
        if (w == "shape") {
            loadShape(shapeView)
            val b = prefs.getInt("sh_color", 0xFF1C2333.toInt())
            if ((Color.red(b) * 299 + Color.green(b) * 587 + Color.blue(b) * 114) / 1000 > 150) c = 0xFF1B1B1F.toInt()
        }
        ((homeView as ViewGroup).getChildAt(0) as TextView).setTextColor(c)
        dots.setTextColor(c)
    }

    private fun wallShow() {
        buildWalls(false)
        settings.visibility = View.VISIBLE
    }

    // Раздел «Обои»: «Лаунчер» (встроенные обои) и «Остальные» (системный выбор)
    private fun buildWalls(sub: Boolean) {
        box.removeAllViews()
        fun label(t: String) = TextView(this).apply { text = t; textSize = 24f; setTextColor(fg); setPadding(0, dp(8), 0, dp(16)) }
        val lp = { LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(8)) } }
        if (!sub) {
            box.addView(label("Обои"))
            box.addView(chip("Лаунчер", false) { buildWalls(true) }, lp())
            box.addView(chip("Остальные", false) {
                prefs.edit().putString("wall", "system").apply()
                applyWall()
                settingsShow(false)
                runCatching { startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Обои")) }
            }, lp())
        } else {
            val cur = prefs.getString("wall", "palm") == "palm"
            val choose = { prefs.edit().putString("wall", "palm").apply(); applyWall(); buildWalls(true) }
            box.addView(label("Обои лаунчера"))
            box.addView(ImageView(this).apply {
                setImageResource(R.drawable.wall_palm)
                scaleType = ImageView.ScaleType.CENTER_CROP
                clipToOutline = true
                outlineProvider = object : ViewOutlineProvider() {
                    override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(20).toFloat()) }
                }
                setOnClickListener { choose() }
            }, LinearLayout.LayoutParams(-1, dp(320)).apply { setMargins(0, 0, 0, dp(12)) })
            box.addView(chip(if (cur) "✓ Установлены" else "Установить", cur) { choose() }, lp())
            box.addView(chip(if (prefs.getString("wall", "palm") == "shape") "✓ Фигуры: изменить" else "Фигуры: создать обои", false) { buildShapes() }, lp())
        }
        box.addView(chip("Назад", false) { if (sub) buildWalls(false) else settingsShow(false) }, lp())
    }

    // Форма значков: 0 - как у приложения, 1 - круг, 2 - скруглённый квадрат
    private fun shapeIcon(d: Drawable): Drawable {
        val sh = prefs.getInt("ishape", 0)
        if (sh == 0) return d
        val n = isz
        val bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val path = Path()
        if (sh == 1) path.addCircle(n / 2f, n / 2f, n / 2f, Path.Direction.CW)
        else path.addRoundRect(RectF(0f, 0f, n.toFloat(), n.toFloat()), n * 0.28f, n * 0.28f, Path.Direction.CW)
        if (Build.VERSION.SDK_INT >= 26 && d is AdaptiveIconDrawable) {
            val o = (n * 0.25f).toInt()
            for (l in listOf(d.background, d.foreground)) {
                l?.setBounds(-o, -o, n + o, n + o)
                l?.draw(c)
            }
        } else {
            c.drawColor(Color.WHITE)
            val i = n * 15 / 100
            d.setBounds(i, i, n - i, n - i)
            d.draw(c)
        }
        c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) })
        return BitmapDrawable(resources, bmp)
    }

    private fun applyIcons() {
        grid.numColumns = cols
        reload()
    }

    private var palmBmp: Bitmap? = null
    private fun palm(): Bitmap? {
        if (palmBmp == null) palmBmp = BitmapFactory.decodeResource(resources, R.drawable.wall_palm)
        return palmBmp
    }

    // Статичные обои телефона: домой - фото на весь экран, экран блокировки - фигура
    private fun setPhoneWall() {
        val wm = WallpaperManager.getInstance(this)
        val w = wm.desiredMinimumWidth.takeIf { it > 0 } ?: resources.displayMetrics.widthPixels
        val h = wm.desiredMinimumHeight.takeIf { it > 0 } ?: resources.displayMetrics.heightPixels
        val art = ShapeWall(this)
        loadShape(art)
        Toast.makeText(this, "Ставлю обои…", Toast.LENGTH_SHORT).show()
        Thread {
            val ok = runCatching {
                fun bmp(t: Float) = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { art.render(Canvas(it), w.toFloat(), h.toFloat(), t) }
                if (Build.VERSION.SDK_INT >= 24) {
                    wm.setBitmap(bmp(1f), null, true, WallpaperManager.FLAG_SYSTEM)
                    wm.setBitmap(bmp(0f), null, true, WallpaperManager.FLAG_LOCK)
                } else wm.setBitmap(bmp(1f))
            }.isSuccess
            runOnUiThread {
                if (ok) { prefs.edit().putString("wall", "system").apply(); applyWall() }
                Toast.makeText(this, if (ok) "Обои установлены на телефон" else "Не удалось установить обои", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    // Живые обои: на экране блокировки фигура, при разблокировке она расширяется до краёв
    private fun setLive() {
        val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, ComponentName(this, ShapeWallpaperService::class.java))
        runCatching { startActivity(i) }.onFailure { runCatching { startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)) } }
        prefs.edit().putString("wall", "system").apply(); applyWall()
    }

    private fun slider(t: String, v: Int, f: (Int) -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(TextView(context).apply { text = t; textSize = 13f; setTextColor(fg); setPadding(0, dp(12), 0, 0) })
        addView(SeekBar(context).apply {
            max = 100; progress = v
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { f(p) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }

    private fun loadShape(v: ShapeWall) {
        if (shapePhoto == null) shapePhoto = BitmapFactory.decodeFile(java.io.File(filesDir, "shape.jpg").path)
        v.shape = prefs.getInt("sh_shape", 1)
        v.bg = prefs.getInt("sh_color", 0xFF1C2333.toInt())
        v.size = prefs.getInt("sh_size", 55)
        v.zoom = prefs.getInt("sh_zoom", 50)
        v.photo = shapePhoto ?: palm()
        v.invalidate()
    }

    // Редактор обоев «Фигуры»
    private fun buildShapes() {
        box.removeAllViews()
        val pv = ShapeWall(this).apply {
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(24).toFloat()) }
            }
        }
        shapePrev = pv
        pv.setOnClickListener {
            ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 900
                addUpdateListener { pv.p = it.animatedValue as Float; pv.invalidate() }
                addListener(object : AnimatorListenerAdapter() { override fun onAnimationEnd(a: Animator) { pv.p = 0f; pv.invalidate() } })
                start()
            }
        }
        loadShape(pv)
        fun upd(k: String, x: Int) { prefs.edit().putInt(k, x).apply(); loadShape(pv); loadShape(shapeView) }
        val gap = { LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(8), 0, 0) } }
        val wt = { LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) } }
        box.addView(TextView(this).apply { text = "Фигуры"; textSize = 24f; setTextColor(fg); setPadding(0, dp(8), 0, dp(12)) })
        box.addView(pv, LinearLayout.LayoutParams(dp(170), dp(368)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        box.addView(TextView(this).apply { text = "Нажмите на картинку: покажу, как фигура расширяется при разблокировке"; textSize = 12f; setTextColor(fg); gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(6)) })
        val cur = prefs.getInt("sh_shape", 1)
        val names = listOf("Круг", "Скруглённый", "Печенька", "Цветок")
        for (r in 0..1) {
            val row = LinearLayout(this)
            for (i in r * 2..r * 2 + 1) row.addView(chip(names[i], cur == i) { upd("sh_shape", i); buildShapes() }, wt())
            box.addView(row, gap())
        }
        val colors = listOf(0xFF4285F4, 0xFF1FB5C9, 0xFF34A853, 0xFFFFC445, 0xFFFF8A3D, 0xFFEE6A9B, 0xFF9B6CF2, 0xFFE8E4DA, 0xFF1C2333).map { it.toInt() }
        val sel = prefs.getInt("sh_color", 0xFF1C2333.toInt())
        for (part in listOf(colors.subList(0, 5), colors.subList(5, 9))) {
            val row = LinearLayout(this)
            part.forEach { col ->
                val dot = View(this).apply {
                    background = GradientDrawable().apply {
                        setShape(GradientDrawable.OVAL)
                        setColor(col)
                        if (col == sel) setStroke(dp(3), fg)
                    }
                    setOnClickListener { upd("sh_color", col); buildShapes() }
                }
                val holder = FrameLayout(this)
                holder.addView(dot, FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER))
                row.addView(holder, LinearLayout.LayoutParams(0, dp(44), 1f))
            }
            box.addView(row, gap())
        }
        box.addView(slider("Размер формы", prefs.getInt("sh_size", 55)) { upd("sh_size", it) })
        box.addView(slider("Приближение фото в форме", prefs.getInt("sh_zoom", 50)) { upd("sh_zoom", it) })
        box.addView(chip("Другое фото", false) { pickPhoto() }, gap())
        box.addView(chip("Обои телефона: домой + экран блокировки", true) { setPhoneWall() }, gap())
        box.addView(chip("Живые обои: расширение при разблокировке", true) { setLive() }, gap())
        box.addView(chip("Только в лаунчере", false) {
            prefs.edit().putString("wall", "shape").apply(); applyWall(); settingsShow(false)
        }, gap())
        box.addView(chip("Назад", false) { buildWalls(true) }, gap())
    }

    @Suppress("DEPRECATION")
    private fun pickPhoto() {
        startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 77)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 77 || res != RESULT_OK) return
        val u = data?.data ?: return
        runCatching {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
            var sm = 1
            while (o.outWidth / sm > 2000 || o.outHeight / sm > 2000) sm *= 2
            val bm = contentResolver.openInputStream(u)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sm })
            }
            if (bm != null) {
                java.io.File(filesDir, "shape.jpg").outputStream().use { bm.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                shapePhoto = bm
                shapePrev?.let { loadShape(it) }
                loadShape(shapeView)
            }
        }
    }

    private fun buildSettings() {
        box.removeAllViews()
        fun label(t: String, size: Float, top: Int) = TextView(this).apply {
            text = t; textSize = size; setTextColor(fg); setPadding(0, dp(top), 0, dp(8))
        }
        box.addView(label("Настройки лаунчера", 24f, 8))
        box.addView(label("Значки", 16f, 16))
        box.addView(slider("Размер значков", (prefs.getInt("isize", 56) - 44) * 100 / 40) {
            prefs.edit().putInt("isize", 44 + it * 40 / 100).apply()
            box.removeCallbacks(iconRun); box.postDelayed(iconRun, 350)
        })
        box.addView(label("Форма", 13f, 12))
        val shRow = LinearLayout(this)
        listOf("Как есть", "Круг", "Квадрат").forEachIndexed { i, t ->
            shRow.addView(chip(t, prefs.getInt("ishape", 0) == i) { prefs.edit().putInt("ishape", i).apply(); buildSettings(); applyIcons() },
                LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0, 0, dp(8), 0) })
        }
        box.addView(shRow)
        box.addView(label("Колонок в сетке", 13f, 12))
        val cRow = LinearLayout(this)
        listOf(3, 4, 5).forEach { n ->
            cRow.addView(chip("$n", cols == n) { prefs.edit().putInt("cols", n).apply(); buildSettings(); applyIcons() },
                LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0, 0, dp(8), 0) })
        }
        box.addView(cRow)
        box.addView(label("Анимации открытия приложений", 16f, 16))
        box.addView(label("Скорость", 13f, 4))
        val slow = prefs.getBoolean("slow", false)
        val row = LinearLayout(this)
        listOf("1x" to false, "0,5x" to true).forEach { (t, sl) ->
            row.addView(chip(t, slow == sl) { prefs.edit().putBoolean("slow", sl).apply(); buildSettings(); preview() },
                LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0, 0, dp(8), 0) })
        }
        box.addView(row)
        box.addView(label("Стиль (нажмите, чтобы посмотреть)", 13f, 16))
        styles.forEachIndexed { i, t ->
            box.addView(chip(t, prefs.getInt("anim", 0) == i) { prefs.edit().putInt("anim", i).apply(); buildSettings(); preview() },
                LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(8)) })
        }
        box.addView(chip("Назад", false) { settingsShow(false) },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
    }

    private fun speedMs() = if (prefs.getBoolean("slow", false)) 600L else 300L

    // Радиус скругления углов экрана (API 31+), иначе 36dp
    private fun cornerR(): Float {
        if (Build.VERSION.SDK_INT >= 31) {
            val c = root.rootWindowInsets?.getRoundedCorner(RoundedCorner.POSITION_TOP_LEFT)
            if (c != null) return c.radius.toFloat()
        }
        return dp(36).toFloat()
    }

    // t: 0 - значок, 1 - окно на весь экран. Одна функция для всех стилей, поэтому анимацию можно развернуть с любого места
    private fun setVeil(t: Float) {
        val w = root.width.toFloat()
        val h = root.height.toFloat()
        val r0 = dp(28).toFloat()
        val u = 1f - t
        val a = t.coerceIn(0f, 1f)
        var al = 1f
        var sc = 1f
        var ty = 0f
        shape = 0
        ol.set(0f, 0f, w, h); orad = crv
        when (vst) {
            0 -> {
                ol.set((lcx - r0) * u, (lcy - r0) * u, (lcx + r0) * u + w * t, (lcy + r0) * u + h * t)
                orad = dp(16) + (crv - dp(16)) * t
                al = minOf(1f, t * 4f)
            }
            1 -> {
                shape = 1
                val rr = r0 * u + Math.hypot(w.toDouble(), h.toDouble()).toFloat() * t
                ol.set(lcx - rr, lcy - rr, lcx + rr, lcy + rr)
            }
            2 -> { sc = 0.7f + 0.3f * t; al = a }
            3 -> ty = h * u
            4 -> al = a
            else -> { sc = 0.3f + 0.7f * t; al = minOf(1f, a * 1.5f) }
        }
        veil.alpha = al; veil.scaleX = sc; veil.scaleY = sc; veil.translationY = ty
        veil.invalidateOutline()
    }

    private fun openVeil(st: Int) {
        va?.removeAllListeners(); va?.cancel()
        vst = st; closing = false; crv = cornerR()
        veil.setBackgroundColor(if (st == 0) sheet else accent)
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.setDuration(speedMs())
        a.setInterpolator(if (st == 0) PathInterpolator(0.05f, 0.7f, 0.1f, 1f) else if (st == 5) OvershootInterpolator() else DecelerateInterpolator())
        a.addUpdateListener { setVeil(it.animatedValue as Float) }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) { if (closing) { closing = false; hideVeil() } }
        })
        va = a
        setVeil(0f)
        veil.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        veil.visibility = View.VISIBLE
        a.start()
    }

    // Свернуть обратно в значок с того места, где анимация сейчас
    private fun closeVeil() {
        val a = va ?: return
        if (veil.visibility != View.VISIBLE || closing) return
        closing = true
        a.setDuration(speedMs())
        a.reverse()
    }

    private fun hideVeil() {
        va?.removeAllListeners(); va?.cancel()
        closing = false
        veil.visibility = View.INVISIBLE
        veil.setLayerType(View.LAYER_TYPE_NONE, null)
    }

    // Возврат из приложения: закрытие окна рисует система, мы плавно «проявляем» рабочий стол за ней
    private fun arrive() {
        val d = speedMs()
        homeView.alpha = 0f; homeView.scaleX = 0.94f; homeView.scaleY = 0.94f
        homeView.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(d / 3).setDuration(d)
            .setInterpolator(DecelerateInterpolator()).start()
    }

    private val closeRun = Runnable { if (!awaiting) closeVeil() }

    private fun preview() {
        val st = prefs.getInt("anim", 0)
        if (st >= styles.size - 1) return
        lcx = root.width / 2; lcy = root.height / 2
        openVeil(st)
        veil.removeCallbacks(closeRun)
        veil.postDelayed(closeRun, speedMs() + 250)
    }

    // Приложение запускается сразу, анимация идёт параллельно и не блокирует экран
    private fun launch(a: App, v: View) {
        val st = prefs.getInt("anim", 0)
        if (st < styles.size - 1) {
            val loc = IntArray(2); v.getLocationOnScreen(loc)
            val rl = IntArray(2); root.getLocationOnScreen(rl)
            lcx = loc[0] - rl[0] + v.width / 2
            lcy = loc[1] - rl[1] + v.height / 2
            openVeil(st)
            awaiting = true; left = false
            veil.postDelayed({ if (awaiting && !left) { awaiting = false; closeVeil() } }, 6000)
        }
        runCatching { startActivity(a.intent, ActivityOptions.makeCustomAnimation(this, 0, 0).toBundle()) }
            .onFailure { awaiting = false; closeVeil() }
        if (isOpen) show(false)
    }

    private fun showMenu(a: App, v: View) {
        PopupMenu(this, v).apply {
            menu.add("О приложении").setOnMenuItemClickListener {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}"))); true
            }
            menu.add("Удалить").setOnMenuItemClickListener {
                startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}"))); true
            }
        }.show()
    }

    private fun show(v: Boolean, focus: Boolean = false) {
        isOpen = v
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        if (v) {
            drawer.visibility = View.VISIBLE
            drawer.translationY = root.height.toFloat()
            drawer.setLayerType(View.LAYER_TYPE_HARDWARE, null)
            drawer.animate().translationY(0f).setDuration(260).withEndAction { drawer.setLayerType(View.LAYER_TYPE_NONE, null) }.start()
            if (focus) search.postDelayed({ search.requestFocus(); imm.showSoftInput(search, 0) }, 280)
        } else {
            if (search.text.isNotEmpty()) search.setText("")
            search.clearFocus(); grid.setSelection(0)
            imm.hideSoftInputFromWindow(search.windowToken, 0)
            drawer.setLayerType(View.LAYER_TYPE_HARDWARE, null)
            drawer.animate().translationY(root.height.toFloat()).setDuration(220)
                .withEndAction { if (!isOpen) drawer.visibility = View.INVISIBLE; drawer.setLayerType(View.LAYER_TYPE_NONE, null) }.start()
        }
    }
}
