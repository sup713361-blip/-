package com.example.pixellauncher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.app.Activity
import android.app.ActivityOptions
import android.content.ClipData
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.InputType
import android.text.TextUtils
import android.view.DragEvent
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewAnimationUtils
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.Space
import android.widget.TextClock
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.doAfterTextChanged

class App(val label: String, val pkg: String, val icon: Drawable, val intent: Intent)

class MainActivity : Activity() {
    private var all = listOf<App>()
    private var isOpen = false
    private lateinit var root: FrameLayout
    private lateinit var dock: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var grid: GridView
    private lateinit var search: EditText
    private lateinit var desk: FrameLayout
    private lateinit var panel: LinearLayout
    private lateinit var scrim: View
    private lateinit var settings: ScrollView
    private lateinit var box: LinearLayout
    private lateinit var bar: LinearLayout
    private val placed = LinkedHashMap<String, Int>()
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }
    private val cols = 4
    private val styles = listOf("Круг из иконки", "Масштаб", "Снизу вверх", "Затухание", "Пружина", "Без анимации")
    private lateinit var veil: View

    // Цвета Material You (динамические, из обоев) + светлая/тёмная тема
    private val dark get() = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES
    private fun pick(night: Int, day: Int, nightFb: Long, dayFb: Long) =
        if (Build.VERSION.SDK_INT >= 31) ContextCompat.getColor(this, if (dark) night else day)
        else (if (dark) nightFb else dayFb).toInt()
    private val fg get() = pick(android.R.color.system_neutral1_50, android.R.color.system_neutral1_900, 0xFFEDEDED, 0xFF1B1B1F)
    private val sheet get() = pick(android.R.color.system_neutral1_900, android.R.color.system_neutral1_10, 0xFF1B1B1F, 0xFFFAFAFA)
    private val pillBg get() = pick(android.R.color.system_neutral2_800, android.R.color.system_accent2_100, 0xFF2E2F36, 0xFFE3E7F2)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun round(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    private val ad = object : BaseAdapter() {
        var items = listOf<App>()
        override fun getCount() = items.size
        override fun getItem(p: Int) = items[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, v: View?, g: ViewGroup?): View = cell(items[p], true)
    }

    private val gd by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null) return false
                val dy = e2.y - e1.y
                if (!isOpen && !overlay() && dy < -dp(60) && vy < -600) { show(true); return true }
                if (isOpen && dy > dp(80) && vy > 800 && !grid.canScrollVertically(-1)) { show(false); return true }
                return false
            }
        })
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        root = FrameLayout(this)
        loadDesk()

        // ---- Главный экран: дата, док, поиск ----
        val home = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setOnLongClickListener { panelShow(true); true }
        }
        home.addView(TextClock(this).apply {
            format12Hour = "EEE, d MMM"; format24Hour = "EEE, d MMM"
            textSize = 30f; setTextColor(Color.WHITE); setShadowLayer(8f, 0f, 2f, 0x66000000)
            typeface = Typeface.create("google-sans", Typeface.NORMAL)
        })
        desk = FrameLayout(this).apply {
            addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
                if (r - l != orr - ol || b - t != ob - ot) post { layoutDesk() }
            }
            setOnDragListener { _, e ->
                if (e.action == DragEvent.ACTION_DROP) dropOnDesk(e)
                true
            }
        }
        home.addView(desk, LinearLayout.LayoutParams(-1, 0, 1f))
        dock = LinearLayout(this).apply { gravity = Gravity.CENTER }
        home.addView(dock, LinearLayout.LayoutParams(-1, -2))
        val pill = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = round(pillBg, 28)
            setPadding(dp(20), 0, dp(20), 0)
            addView(ImageView(context).apply {
                setImageResource(android.R.drawable.ic_menu_search); setColorFilter(fg)
            }, LinearLayout.LayoutParams(dp(24), dp(24)))
            addView(TextView(context).apply {
                text = "Поиск"; textSize = 16f; setTextColor(fg); setPadding(dp(16), 0, 0, 0)
            })
            setOnClickListener { show(true, true) }
        }
        home.addView(pill, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(12) })

        // ---- Шторка приложений ----
        search = EditText(this).apply {
            hint = "Поиск приложений"; textSize = 16f
            setTextColor(fg); setHintTextColor(fg and 0x99FFFFFF.toInt())
            background = round(pillBg, 28)
            setPadding(dp(20), 0, dp(20), 0)
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_GO
            doAfterTextChanged { t ->
                val q = t?.toString() ?: ""
                ad.items = all.filter { it.label.contains(q, true) }
                ad.notifyDataSetChanged()
            }
            setOnEditorActionListener { _, _, _ -> ad.items.firstOrNull()?.let { launch(it, this) }; true }
        }
        grid = GridView(this).apply {
            numColumns = 4; verticalSpacing = dp(8); clipToPadding = false
            setPadding(dp(8), dp(8), dp(8), 0)
            selector = ColorDrawable(Color.TRANSPARENT)
            adapter = ad
            setOnItemClickListener { _, v, p, _ -> launch(ad.items[p], v) }
            setOnItemLongClickListener { _, v, p, _ -> drag(ad.items[p], v); true }
        }
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            background = GradientDrawable().apply {
                setColor(sheet)
                setCornerRadii(FloatArray(8) { if (it < 4) dp(28).toFloat() else 0f })
            }
            addView(search, LinearLayout.LayoutParams(-1, dp(56)).apply { setMargins(dp(16), dp(8), dp(16), dp(8)) })
            addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        }

        root.addView(home, -1, -1)
        root.addView(drawer, -1, -1)

        // ---- Нижняя панель (долгое нажатие), цели перетаскивания, настройки ----
        scrim = View(this).apply { setBackgroundColor(0x66000000); visibility = View.GONE; setOnClickListener { panelShow(false) } }
        panel = LinearLayout(this).apply {
            visibility = View.GONE
            background = GradientDrawable().apply {
                setColor(sheet)
                setCornerRadii(FloatArray(8) { if (it < 4) dp(28).toFloat() else 0f })
            }
            val lp = { LinearLayout.LayoutParams(0, dp(56), 1f).apply { setMargins(dp(8), 0, dp(8), 0) } }
            addView(chip("Обои", false) {
                panelShow(false)
                runCatching { startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Обои")) }
            }, lp())
            addView(chip("Настройки лаунчера", false) { panelShow(false); settingsShow(true) }, lp())
        }
        bar = LinearLayout(this).apply {
            alpha = 0f
            addView(target("Убрать") { placed.remove(it); saveDesk(); desk.post { layoutDesk() } }, tl())
            addView(target("О приложении") { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$it"))) }, tl())
            addView(target("Удалить") { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$it"))) }, tl())
        }
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        settings = ScrollView(this).apply { visibility = View.GONE; setBackgroundColor(sheet); addView(box) }
        root.addView(scrim, -1, -1)
        root.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        root.addView(bar, FrameLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(8), dp(12), 0) })
        root.addView(settings, -1, -1)
        veil = View(this).apply {
            setBackgroundColor(pick(android.R.color.system_accent1_700, android.R.color.system_accent1_200, 0xFF3F51B5, 0xFFC5CAE9))
            visibility = View.INVISIBLE
            isClickable = true
        }
        root.addView(veil, -1, -1)
        root.setOnDragListener { _, e ->
            if (e.action == DragEvent.ACTION_DRAG_STARTED) bar.animate().alpha(1f).setDuration(120).start()
            if (e.action == DragEvent.ACTION_DRAG_ENDED) bar.animate().alpha(0f).setDuration(120).start()
            true
        }
        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, w ->
            val b = w.getInsets(WindowInsetsCompat.Type.systemBars())
            val bottom = maxOf(b.bottom, w.getInsets(WindowInsetsCompat.Type.ime()).bottom)
            home.setPadding(dp(16), b.top + dp(24), dp(16), bottom + dp(16))
            drawer.setPadding(0, b.top, 0, bottom)
            settings.setPadding(dp(24), b.top + dp(16), dp(24), bottom + dp(16))
            panel.setPadding(dp(16), dp(24), dp(16), bottom + dp(24))
            (bar.layoutParams as FrameLayout.LayoutParams).topMargin = b.top + dp(8)
            bar.requestLayout()
            w
        }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        when {
            settings.visibility == View.VISIBLE -> settingsShow(false)
            scrim.visibility == View.VISIBLE -> panelShow(false)
            isOpen -> show(false)
        }
    }

    override fun onStart() {
        super.onStart()
        veil.animate().cancel()
        veil.visibility = View.INVISIBLE
        reload()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (isOpen) show(false)
        settingsShow(false)
        if (scrim.visibility == View.VISIBLE) panelShow(false)
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gd.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    private fun cell(a: App, labels: Boolean, wall: Boolean = false) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(4), dp(8), dp(4), dp(8))
        addView(ImageView(context).apply { setImageDrawable(a.icon) }, LinearLayout.LayoutParams(dp(56), dp(56)))
        if (labels) addView(TextView(context).apply {
            text = a.label; textSize = 12f; maxLines = 1
            ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
            setTextColor(if (wall) Color.WHITE else fg); setPadding(0, dp(4), 0, 0)
            if (wall) setShadowLayer(6f, 0f, 2f, 0x99000000.toInt())
        })
    }

    @Suppress("DEPRECATION")
    private fun reload() {
        val pm = packageManager
        all = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),
            0
        ).filter { it.activityInfo.packageName != packageName }.map { r ->
            val p = r.activityInfo.packageName
            App(
                r.loadLabel(pm).toString(), p, r.loadIcon(pm),
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    .setClassName(p, r.activityInfo.name)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            )
        }.sortedBy { it.label.lowercase() }
        ad.items = all
        ad.notifyDataSetChanged()

        // Док: телефон, сообщения, браузер, камера (приложения по умолчанию)
        dock.removeAllViews()
        listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://")).addCategory(Intent.CATEGORY_BROWSABLE),
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        ).mapNotNull {
            pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)
                ?.activityInfo?.packageName
        }.distinct().mapNotNull { p -> all.firstOrNull { it.pkg == p } }.forEach { a ->
            dock.addView(
                cell(a, false).apply { setOnClickListener { launch(a, it) } },
                LinearLayout.LayoutParams(0, -2, 1f)
            )
        }
        layoutDesk()
    }

    private fun rows() = maxOf(1, desk.height / dp(92))

    private fun overlay() = settings.visibility == View.VISIBLE || scrim.visibility == View.VISIBLE

    private fun saveDesk() = prefs.edit().putString("desk", placed.entries.joinToString(",") { it.key + "=" + it.value }).apply()

    private fun loadDesk() {
        placed.clear()
        (prefs.getString("desk", "") ?: "").split(",").forEach { s ->
            val p = s.split("=")
            if (p.size == 2) p[1].toIntOrNull()?.let { placed[p[0]] = it }
        }
    }

    // Значки на рабочем столе: сетка cols x rows, позиция = ряд*10 + колонка
    private fun layoutDesk() {
        if (desk.width == 0 || all.isEmpty()) return
        desk.removeAllViews()
        val cw = desk.width / cols
        val ch = desk.height / rows()
        placed.entries.toList().forEach { (pkg, pos) ->
            val a = all.firstOrNull { it.pkg == pkg } ?: return@forEach
            val c = cell(a, true, true).apply {
                setOnClickListener { launch(a, it) }
                setOnLongClickListener { drag(a, it); true }
            }
            desk.addView(c, FrameLayout.LayoutParams(cw, ch).apply {
                leftMargin = (pos % 10).coerceAtMost(cols - 1) * cw
                topMargin = (pos / 10).coerceAtMost(rows() - 1) * ch
            })
        }
    }

    private fun dropOnDesk(e: DragEvent) {
        val pkg = e.clipData?.getItemAt(0)?.text?.toString() ?: return
        val rw = rows()
        val c = (e.x / (desk.width / cols)).toInt().coerceIn(0, cols - 1)
        val r = (e.y / (desk.height / rw)).toInt().coerceIn(0, rw - 1)
        placed.remove(pkg)
        val taken = placed.values.toSet()
        val spot = (0 until rw * cols).map { (it / cols) * 10 + it % cols }.filter { it !in taken }
            .minByOrNull { val dr = it / 10 - r; val dc = it % 10 - c; dr * dr + dc * dc } ?: return
        placed[pkg] = spot
        saveDesk()
        desk.post { layoutDesk() }
    }

    @Suppress("DEPRECATION")
    private fun drag(a: App, v: View) {
        v.startDrag(ClipData.newPlainText("pkg", a.pkg), View.DragShadowBuilder(v), null, 0)
        if (isOpen) show(false)
    }

    private fun tl() = LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(4), 0, dp(4), 0) }

    private fun target(t: String, act: (String) -> Unit) = TextView(this).apply {
        text = t; textSize = 13f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        background = round(0xCC333333.toInt(), 24)
        setOnDragListener { v, e ->
            when (e.action) {
                DragEvent.ACTION_DRAG_ENTERED -> v.alpha = 0.6f
                DragEvent.ACTION_DRAG_EXITED, DragEvent.ACTION_DRAG_ENDED -> v.alpha = 1f
                DragEvent.ACTION_DROP -> e.clipData?.getItemAt(0)?.text?.toString()?.let(act)
            }
            true
        }
    }

    private fun chip(t: String, sel: Boolean, click: () -> Unit) = TextView(this).apply {
        text = t; textSize = 15f; gravity = Gravity.CENTER; setTextColor(fg)
        setPadding(dp(16), dp(12), dp(16), dp(12))
        background = round(if (sel) pick(android.R.color.system_accent1_700, android.R.color.system_accent1_200, 0xFF3F51B5, 0xFFC5CAE9) else pillBg, 28)
        setOnClickListener { click() }
    }

    private fun panelShow(v: Boolean) {
        if (v) {
            scrim.visibility = View.VISIBLE
            panel.visibility = View.VISIBLE
            panel.translationY = dp(200).toFloat()
            panel.animate().translationY(0f).setDuration(200).start()
        } else {
            scrim.visibility = View.GONE
            panel.animate().translationY(dp(200).toFloat()).setDuration(160)
                .withEndAction { if (scrim.visibility == View.GONE) panel.visibility = View.GONE }.start()
        }
    }

    private fun settingsShow(v: Boolean) {
        if (v) buildSettings()
        settings.visibility = if (v) View.VISIBLE else View.GONE
    }

    private fun buildSettings() {
        box.removeAllViews()
        fun label(t: String, size: Float, top: Int) = TextView(this).apply {
            text = t; textSize = size; setTextColor(fg); setPadding(0, dp(top), 0, dp(8))
        }
        box.addView(label("Настройки лаунчера", 24f, 8))
        box.addView(label("Анимации открытия приложений", 16f, 16))
        box.addView(label("Скорость", 13f, 4))
        val slow = prefs.getBoolean("slow", false)
        val row = LinearLayout(this)
        listOf("1x" to false, "0,5x" to true).forEach { (t, sl) ->
            row.addView(chip(t, slow == sl) { prefs.edit().putBoolean("slow", sl).apply(); buildSettings(); preview() },
                LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0, 0, dp(8), 0) })
        }
        box.addView(row)
        box.addView(label("Стиль (нажмите, чтобы посмотреть)", 13f, 16))
        styles.forEachIndexed { i, t ->
            box.addView(chip(t, prefs.getInt("anim", 0) == i) { prefs.edit().putInt("anim", i).apply(); buildSettings(); preview() },
                LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(8)) })
        }
        box.addView(chip("Назад", false) { settingsShow(false) },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
    }

    private fun speedMs() = if (prefs.getBoolean("slow", false)) 600L else 300L

    // Анимация открытия: цветная шторка раскрывается из точки (cx, cy), затем вызывается end
    private fun playVeil(cx: Int, cy: Int, st: Int, end: () -> Unit) {
        val d = speedMs()
        val w = root.width.toFloat()
        val h = root.height.toFloat()
        val done = Runnable { end() }
        veil.animate().cancel()
        veil.alpha = 1f; veil.scaleX = 1f; veil.scaleY = 1f; veil.translationY = 0f
        when (st) {
            0 -> {
                val r = ViewAnimationUtils.createCircularReveal(veil, cx, cy, dp(28).toFloat(), Math.hypot(w.toDouble(), h.toDouble()).toFloat())
                r.setDuration(d)
                r.setInterpolator(AccelerateDecelerateInterpolator())
                r.addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) { end() }
                })
                veil.visibility = View.VISIBLE
                r.start()
            }
            1 -> {
                veil.scaleX = 0.7f; veil.scaleY = 0.7f; veil.alpha = 0f
                veil.visibility = View.VISIBLE
                veil.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(d).setInterpolator(DecelerateInterpolator()).withEndAction(done).start()
            }
            2 -> {
                veil.translationY = h
                veil.visibility = View.VISIBLE
                veil.animate().translationY(0f).setDuration(d).setInterpolator(DecelerateInterpolator()).withEndAction(done).start()
            }
            3 -> {
                veil.alpha = 0f
                veil.visibility = View.VISIBLE
                veil.animate().alpha(1f).setDuration(d).withEndAction(done).start()
            }
            else -> {
                veil.scaleX = 0.3f; veil.scaleY = 0.3f; veil.alpha = 0f
                veil.visibility = View.VISIBLE
                veil.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(d).setInterpolator(OvershootInterpolator()).withEndAction(done).start()
            }
        }
    }

    private fun preview() {
        val st = prefs.getInt("anim", 0)
        if (st < styles.size - 1) playVeil(root.width / 2, root.height / 2, st) {
            veil.postDelayed({ veil.visibility = View.INVISIBLE }, 250)
        }
    }

    private fun launch(a: App, v: View) {
        fun go() {
            runCatching { startActivity(a.intent, ActivityOptions.makeCustomAnimation(this, 0, 0).toBundle()) }
            if (isOpen) show(false)
            veil.postDelayed({ veil.visibility = View.INVISIBLE }, 700)
        }
        val st = prefs.getInt("anim", 0)
        if (st >= styles.size - 1) return go()
        val loc = IntArray(2); v.getLocationOnScreen(loc)
        val rl = IntArray(2); root.getLocationOnScreen(rl)
        playVeil(loc[0] - rl[0] + v.width / 2, loc[1] - rl[1] + v.height / 2, st) { go() }
    }

    private fun showMenu(a: App, v: View) {
        PopupMenu(this, v).apply {
            menu.add("О приложении").setOnMenuItemClickListener {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}"))); true
            }
            menu.add("Удалить").setOnMenuItemClickListener {
                startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}"))); true
            }
        }.show()
    }

    private fun show(v: Boolean, focus: Boolean = false) {
        isOpen = v
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        if (v) {
            drawer.visibility = View.VISIBLE
            drawer.translationY = root.height.toFloat()
            drawer.animate().translationY(0f).setDuration(260).start()
            if (focus) search.postDelayed({ search.requestFocus(); imm.showSoftInput(search, 0) }, 280)
        } else {
            search.setText(""); search.clearFocus(); grid.setSelection(0)
            imm.hideSoftInputFromWindow(search.windowToken, 0)
            drawer.animate().translationY(root.height.toFloat()).setDuration(220)
                .withEndAction { if (!isOpen) drawer.visibility = View.GONE }.start()
        }
    }
}
